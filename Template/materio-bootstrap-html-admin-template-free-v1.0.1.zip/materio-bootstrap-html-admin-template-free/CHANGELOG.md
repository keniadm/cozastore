# Changelog

All notable changes to this template will be documented in this file

## [1.0.1] - [2022-09-26]

### Added

- Linting, formatting, .git, vscode extensions & setting files

## [1.0.0] - [2022-09-20]

### Added

- Initial Release
